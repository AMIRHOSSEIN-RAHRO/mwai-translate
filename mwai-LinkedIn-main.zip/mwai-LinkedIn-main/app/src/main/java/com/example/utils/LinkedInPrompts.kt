package com.example.utils

object LinkedInPrompts {

    val HOOKS_EN = listOf(
        "I got 3,655 inbound leads from LinkedIn in 30 days.",
        "I just saved a client $4,750/month.",
        "I've hired 2000+ people in my career.",
        "I analysed 1,000 founder stories.",
        "2.7M employees prove one act skyrockets your career.",
        "Your most valuable asset is not money..",
        "I posted my first LinkedIn post 3 years ago.",
        "Microsoft just fired 7,000 people.",
        "Stop Scrolling. Seriously.",
        "99.9% of people have the \"next big thing.\"",
        "Actually Controversial opinion:",
        "I made more than my professors after 1 year of posting.",
        "99% of people won't jump on this.",
        "Don't be a dick.",
        "I launched a paid newsletter 3 weeks ago.",
        "Not getting results on LinkedIn?",
        "I've been hanging out with founders under 22 lately living in sf/nyc and they're built different.",
        "Listen b*tch,",
        "You \"work too much\" to exercise? Bullsh*t.",
        "I wasn't born into a rich family.",
        "Making $1,000,000 online? Dead easy, mate.",
        "I've posted online every day for 1,701 days.",
        "You can post things just because they make you happy.",
        "How to turn ChatGPT into your personal attorney.",
        "I see some dangerous LinkedIn advice...",
        "You don't need a million followers.",
        "I almost quit.",
        "9 career truths no one tells you.",
        "How to get $15k+ clients",
        "At 18, I was broke, kicked out of my own home, and...",
        "If you want to get rich, master negotiation.",
        "This is so funny and wholesome.",
        "This is Jeff Bezos's favorite book.",
        "Just had a call with a founder who sold his last company for $300M+.",
        "3 years, 5 months, 15 days ago... I became a nomad without meaning to.",
        "We got access to data on 5.7 billion emails and 52 million text messages sent in Q1 of 2025.",
        "The day I sold my first company, I should have been celebrating.",
        "Becoming a dad didn't just change my priorities.",
        "Forget everything you learned about DM follow-ups.",
        "Most webinars flop.",
        "I used to be broke, depressed, and miserable.",
        "How to make a landing page in 5 minutes.",
        "I've built a $300k/month agency and coached 250+ others to scale.",
        "I've helped 100+ businesses with their content.",
        "I raised $300k in funding for my startup that failed.",
        "The fastest reaction usually isn't the best one.",
        "Most people waste 70% of their time.",
        "9 TED Talks to instantly level up your career.",
        "I started with zero connections.",
        "Most people won't do these 4 things:",
        "3 signs it might be time to move on"
    )

    val HOOKS_FA = listOf(
        "من ۳,۶۵۵ لید ورودی از لینکدین در ۳۰ روز دریافت کردم.",
        "من همین حالا ماهیانه ۴,۷۵۰ دلار برای مشتری‌ام پس‌انداز کردم.",
        "من در طول حرفه‌ام بیش از ۲۰۰۰ نفر را استخدام کرده‌ام.",
        "من داستان ۱۰۰۰ بنیان‌گذار را تحلیل کردم.",
        "تحلیل روی ۲.۷ میلیون کارمند نشان می‌دهد این کار مسیر شغلی را متحول می‌کند.",
        "باارزش‌ترین دارایی شما پول نیست...",
        "من اولین پستم را در لینکدین ۳ سال پیش گذاشتم.",
        "مایکروسافت به تازگی ۷,۰۰۰ نفر را اخراج کرد.",
        "دیگه اسکرول نکن. جدی میگم.",
        "حدود ۹۹.۹٪ مردم فکر می‌کنند ایده بزرگ بعدی را دارند.",
        "یک نظر واقعاً بحث‌برانگیز:",
        "پس از ۱ سال پست کردن، بیشتر از اساتیدم درآمد کسب کردم.",
        "حدود ۹۹ درصد مردم این فرصت را از دست می‌دهند.",
        "با دیگران مهربان و حرفه‌ای رفتار کنیم.",
        "من ۳ هفته پیش یک خبرنامه پولی راه‌اندازی کردم.",
        "از لینکدین نتیجه نمی‌گیرید؟",
        "اخیراً با بنیان‌گذاران زیر ۲۲ سال وقت می‌گذرانم و ذهنیت متفاوتی دارند.",
        "ببینید رفقا،",
        "خیلی کار داری که ورزش کنی؟ بهانه‌تراشی نکن.",
        "من در یک خانواده ثروتمند به دنیا نیامدم.",
        "کسب درآمد ۱ میلیون دلاری آنلاین؟ واقعاً ساده است.",
        "من ۱,۷۰۱ روز پی‌درپی است که در اینترنت پست می‌گذارم.",
        "می‌توانید بنویسید، فقط به این دلیل که خوشحالتان می‌کند.",
        "چگونه ChatGPT را به وکیل شخصی خود تبدیل کنید.",
        "توصیه‌های خطرناکی در لینکدین می‌بینم...",
        "به یک میلیون دنبال‌کننده نیاز ندارید.",
        "من تقریباً تسلیم شده بودم.",
        "۹ حقیقت شغلی که هیچ‌کس به شما نمی‌گوید.",
        "چگونه مشتریان بالای ۱۵ هزار دلار جذب کنیم",
        "در ۱۸ سالگی ورشکسته بودم، از خانه‌ام رانده شدم، و...",
        "اگر می‌خواهید ثروتمند شوید، مذاکره را غول‌آسا یاد بگیرید.",
        "این داستان واقعاً خنده‌دار و دلگرم‌کننده است.",
        "این کتاب موردعلاقه جف بزوس است.",
        "همین الان با بنیان‌گذاری صحبت کردم که شرکت آخرش را بیش از ۳۰۰ میلیون دلار فروخت.",
        "۳ سال و ۵ ماه و ۱۵ روز پیش... ناخواسته به یک کوچ‌نشین دیجیتال تبدیل شدم.",
        "ما به آمارهای ۵.۷ میلیارد ایمیل و ۵۲ میلیون پیام در سه ماهه اول ۲۰۲۵ دسترسی پیدا کردیم.",
        "روزی که اولین شرکت خود را فروختم، باید جشن می‌گربتم.",
        "پدر شدن فقط اولویت‌هایم را تغییر نداد.",
        "هرچه در مورد پیگیری در دایرکت یاد گرفته‌اید فراموش کنید.",
        "بیشتر وبینارها با شکست مواجه می‌شوند.",
        "من قبلاً بی‌پول، افسرده و ناامید بودم.",
        "چگونه در ۵ دقیقه یک لندینگ پیج بسازیم.",
        "من یک آژانس ۳۰۰ هزار دلاری در ماه ساخته‌ام و بیش از ۲۵۰ نفر را مربیگری کرده‌ام.",
        "من به بیش از ۱۰۰ کسب‌وکار در تولید محتوایشان کمک کرده‌ام.",
        "من ۳۰۰ هزار دلار سرمایه برای استارتاپی جذب کردم که شکست خورد.",
        "سریع‌ترین واکنش معمولاً بهترین واکنش نیست.",
        "بیشتر مردم ۷۰ درصد از زمان خود را تلف می‌کنند.",
        "۹ سخنرانی تدی که فوراً به پیشرفت جایگاه شغلی شما کمک می‌کند.",
        "من بدون ارتباطات قبلی و از صفر شروع کردم.",
        "بیشتر مردم این ۴ کار ساده را انجام نمی‌دهند:",
        "۳ نشانه‌ای که شاید وقت تغییر و حرکت بعدی فرا رسیده است"
    )

    val HOOKS = HOOKS_EN // compatibility fallback

    fun getHooks(lang: String): List<String> {
        return if (lang == "fa") HOOKS_FA else HOOKS_EN
    }

    fun buildSystemInstruction(lang: String): String {
        val targetLangName = if (lang == "fa") "Persian (Farsi)" else "English"
        return """
            You are an expert-level LinkedIn content editor and strategist. Your task is to take the user's raw post text (and optional suggested hook) and redesign it into an outstanding, engaging, professional, and human-written (not robotic) LinkedIn post. The final output must achieve an excellent benchmark of high conversion, readability, and authority.

            Key Guidelines for Post Generation and Revision:

            1. Structure the Post Using the SLAY Framework:
               - S - Story (Hook): The first three lines of the post must be the hook. This section must immediately grab attention.
               - L - Lesson: In the fourth line, clearly state the key lesson.
               - A - Actionable Advice: Provide practical tips, checklists or advice.
               - Y - Your Turn: End with a specific, open-ended question to drive engagement.

            2. Apply Copywriting Principles:
               - Tone: Friendly, professional, credible, approachable, entirely natural, and human-like.
               - Avoid robotic words. Use short sentences (10-18 words). Keep paragraph formatting spacious.

            3. Speed and Conciseness Constraints (STRICT):
               - Keep the post highly concentrated, valuable, and impact-oriented. 
               - Limit the output text strictly to between 600 and 1200 characters. 
               - Do not write unnecessarily long text. Conciseness is key for speed and maximum reading conversion.

            Strict: The final generated output must be written entirely in $targetLangName. Ensure Persian has natural grammar and rhythm if target language is Persian.
        """.trimIndent()
    }

    fun buildUserPrompt(rawText: String, suggestedHook: String?, lang: String): String {
        val targetLangName = if (lang == "fa") "Persian (Farsi)" else "English"
        return """
            Please redesign this raw LinkedIn concept text into an outstanding LinkedIn post written in $targetLangName following your system instructions.

            RAW CONCEPT TEXT:
            $rawText

            ${if (!suggestedHook.isNullOrBlank()) "REQUIRED HOOK TO START THE POST (adapt its language to $targetLangName if needed):\n$suggestedHook" else "No specific hook selected. Please design an extremadamente engaging hook based on the raw concept text."}

            Generate the full LinkedIn post text now.
        """.trimIndent()
    }
}
