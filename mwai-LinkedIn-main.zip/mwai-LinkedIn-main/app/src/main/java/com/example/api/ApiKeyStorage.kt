package com.example.api

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class ApiKeyConfig(
    val id: String,
    val provider: String, // "Gemini" or "OpenAI"
    val modelName: String, // e.g., "gemini-1.5-flash", "gemini-2.5-flash", "gpt-4o-mini", "gpt-4o"
    val apiKey: String,
    val isEnabled: Boolean = true
)

object ApiKeyStorage {
    private const val PREFS_NAME = "linkedin_api_keys"
    private const val KEYS_PREF_KEY = "configured_keys"

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val listType = Types.newParameterizedType(List::class.java, ApiKeyConfig::class.java)
    private val adapter by lazy { moshi.adapter<List<ApiKeyConfig>>(listType) }

    fun getKeys(context: Context): List<ApiKeyConfig> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEYS_PREF_KEY, null) ?: return emptyList()
        return try {
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveKeys(context: Context, keys: List<ApiKeyConfig>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = adapter.toJson(keys)
        prefs.edit().putString(KEYS_PREF_KEY, json).apply()
    }

    fun addKey(context: Context, key: ApiKeyConfig) {
        val currentKeys = getKeys(context).toMutableList()
        // Replace if ID matches, else add
        val index = currentKeys.indexOfFirst { it.id == key.id }
        if (index != -1) {
            currentKeys[index] = key
        } else {
            currentKeys.add(key)
        }
        saveKeys(context, currentKeys)
    }

    fun deleteKey(context: Context, id: String) {
        val currentKeys = getKeys(context).filter { it.id != id }
        saveKeys(context, currentKeys)
    }

    fun toggleKey(context: Context, id: String, enabled: Boolean) {
        val currentKeys = getKeys(context).map {
            if (it.id == id) it.copy(isEnabled = enabled) else it
        }
        saveKeys(context, currentKeys)
    }
}
