package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "linkedin_posts")
data class LinkedInPost(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val topic: String,
    val selectedHook: String?,
    val generatedPost: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface LinkedInPostDao {
    @Query("SELECT * FROM linkedin_posts ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<LinkedInPost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: LinkedInPost)

    @Query("DELETE FROM linkedin_posts WHERE id = :id")
    suspend fun deletePostById(id: Int)

    @Query("DELETE FROM linkedin_posts")
    suspend fun clearAllHistory()
}

@Database(entities = [LinkedInPost::class], version = 1, exportSchema = false)
abstract class LinkedInDatabase : RoomDatabase() {
    abstract fun postDao(): LinkedInPostDao

    companion object {
        @Volatile
        private var INSTANCE: LinkedInDatabase? = null

        fun getDatabase(context: Context): LinkedInDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LinkedInDatabase::class.java,
                    "linkedin_posts_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class LinkedInRepository(private val postDao: LinkedInPostDao) {
    val allHistory: Flow<List<LinkedInPost>> = postDao.getAllHistory()

    suspend fun insert(post: LinkedInPost) {
        postDao.insertPost(post)
    }

    suspend fun deleteById(id: Int) {
        postDao.deletePostById(id)
    }

    suspend fun clearAll() {
        postDao.clearAllHistory()
    }
}
