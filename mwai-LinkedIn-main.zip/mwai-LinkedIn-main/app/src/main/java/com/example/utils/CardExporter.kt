package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.OutputStream

object CardExporter {

    fun generatePostCard(
        context: Context,
        name: String,
        handle: String,
        quote: String,
        bgStyle: Int, // 0: Pure Black, 1: Slate Dark, 2: Dark Accent Gradient, 3: High Contrast Light, 4: Professional Gray
        onSuccess: (Uri) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        try {
            // Load custom local Vazirmatn fonts
            val vazirRegular = try {
                androidx.core.content.res.ResourcesCompat.getFont(context, com.example.R.font.vazirmatn_regular)
            } catch (e: Exception) {
                android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.NORMAL)
            }

            val vazirBold = try {
                androidx.core.content.res.ResourcesCompat.getFont(context, com.example.R.font.vazirmatn_bold)
            } catch (e: Exception) {
                android.graphics.Typeface.create(android.graphics.Typeface.SANS_SERIF, android.graphics.Typeface.BOLD)
            }

            // Standard LinkedIn visual ratio is Square (1080x1080) for post graphics
            val size = 1080
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // 1. Draw Background
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            when (bgStyle) {
                0 -> { // Pure Black
                    canvas.drawColor(Color.parseColor("#000000"))
                }
                1 -> { // Slate Dark
                    canvas.drawColor(Color.parseColor("#0F0F10"))
                }
                2 -> { // Dark Accent Gradient
                    val gradient = android.graphics.LinearGradient(
                        0f, 0f, size.toFloat(), size.toFloat(),
                        Color.parseColor("#050505"), Color.parseColor("#1C1E24"),
                        android.graphics.Shader.TileMode.CLAMP
                    )
                    bgPaint.shader = gradient
                    canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bgPaint)
                    bgPaint.shader = null
                }
                3 -> { // High Contrast Light
                    canvas.drawColor(Color.parseColor("#FFFFFF"))
                }
                4 -> { // Professional Gray
                    canvas.drawColor(Color.parseColor("#F4F4F6"))
                }
            }

            // Draw border / styling
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 12f
                color = if (bgStyle == 3 || bgStyle == 4) Color.parseColor("#E5E5EA") else Color.parseColor("#1C1C1E")
            }
            canvas.drawRect(30f, 30f, size - 30f, size - 30f, borderPaint)

            // Dynamic Accent Line
            val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (bgStyle == 3 || bgStyle == 4) Color.parseColor("#000000") else Color.parseColor("#FFFFFF")
            }
            canvas.drawRect(30f, 30f, 120f, 36f, accentPaint)
            canvas.drawRect(30f, 30f, 36f, 120f, accentPaint)

            // 2. Draw Logo/App Name ("mwai LinkedIn")
            val isDarkBg = bgStyle != 3 && bgStyle != 4
            val textColor = if (isDarkBg) Color.WHITE else Color.BLACK
            val subTextColor = if (isDarkBg) Color.parseColor("#8E8E93") else Color.parseColor("#636366")

            val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = textColor
                textSize = 34f
                typeface = vazirBold
                letterSpacing = 0.05f
            }
            canvas.drawText("mwai LinkedIn", 80f, 110f, logoPaint)

            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (isDarkBg) Color.parseColor("#FFFFFF") else Color.parseColor("#000000")
            }
            canvas.drawCircle(326f, 98f, 6f, dotPaint)

            // 3. Draw Profile / Sender Info
            val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = textColor
                textSize = 42f
                typeface = vazirBold
            }
            canvas.drawText(name, 80f, 210f, namePaint)

            val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = subTextColor
                textSize = 30f
                typeface = vazirRegular
                letterSpacing = 0.02f
            }
            canvas.drawText(handle, 80f, 255f, handlePaint)

            // Draw divider
            val divPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (isDarkBg) Color.parseColor("#2C2C2E") else Color.parseColor("#E5E5EA")
                strokeWidth = 3f
            }
            canvas.drawLine(80f, 290f, size - 80f, 290f, divPaint)

            // 4. Quotation graphic
            val quoteMarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (isDarkBg) Color.parseColor("#151518") else Color.parseColor("#F4F4F6")
                textSize = 320f
                typeface = vazirBold
            }
            canvas.drawText("“", 80f, 520f, quoteMarkPaint)

            // 5. Draw the Dynamic Quote Text (StaticLayout for wrapping)
            val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = textColor
                textSize = 36f
                typeface = vazirRegular
            }

            val textWidth = size - 160
            val textLayout = StaticLayout.Builder.obtain(quote, 0, quote.length, textPaint, textWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.35f)
                .build()

            canvas.save()
            val textY = 350f
            canvas.translate(80f, textY)
            textLayout.draw(canvas)
            canvas.restore()

            // 6. Draw Footer Branding / "AI GENERATED" Tag
            val tagRect = RectF(80f, size - 110f, 310f, size - 65f)
            val tagBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (isDarkBg) Color.parseColor("#1C1C1E") else Color.parseColor("#E5E5EA")
            }
            canvas.drawRoundRect(tagRect, 8f, 8f, tagBgPaint)

            val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = textColor
                textSize = 22f
                typeface = vazirBold
            }
            canvas.drawText("LINKEDIN CARD", 100f, size - 78f, tagTextPaint)

            val footPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = subTextColor
                textSize = 26f
                typeface = vazirRegular
            }
            canvas.drawText("JALB • ACCELERATE • INBOUND", size - 440f, size - 78f, footPaint)

            saveBitmapToGallery(context, bitmap, "mwai_post_${System.currentTimeMillis()}.png", onSuccess, onFailure)

        } catch (e: Exception) {
            onFailure(e)
        }
    }

    private fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        filename: String,
        onSuccess: (Uri) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/mwai_linkedin")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        var uri: Uri? = null

        try {
            uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            if (uri == null) {
                throw Exception("Failed to insert MediaStore record")
            }

            val outputStream: OutputStream? = resolver.openOutputStream(uri)
            if (outputStream == null) {
                throw Exception("Failed to open output stream")
            }

            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            outputStream.close()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
            }

            onSuccess(uri)
        } catch (e: Exception) {
            if (uri != null) {
                try {
                    resolver.delete(uri, null, null)
                } catch (ex: Exception) {
                    // Ignore
                }
            }
            onFailure(e)
        }
    }

    fun saveRawImageToGallery(
        context: Context,
        bitmap: Bitmap,
        filename: String,
        onSuccess: (Uri) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        saveBitmapToGallery(context, bitmap, filename, onSuccess, onFailure)
    }
}
