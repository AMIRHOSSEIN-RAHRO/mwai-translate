package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = White,
    onPrimary = Black,
    primaryContainer = AccentGray,
    onPrimaryContainer = White,
    secondary = LightGray,
    onSecondary = Black,
    tertiary = MidGray,
    onTertiary = White,
    background = Black,
    onBackground = White,
    surface = NearBlack,
    onSurface = White,
    surfaceVariant = SolidGray,
    onSurfaceVariant = White,
    outline = BorderDark,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = Black,
    onPrimary = White,
    primaryContainer = LightGray,
    onPrimaryContainer = Black,
    secondary = DarkGray,
    onSecondary = White,
    tertiary = MidGray,
    onTertiary = Black,
    background = White,
    onBackground = Black,
    surface = White,
    onSurface = Black,
    surfaceVariant = LightGray,
    onSurfaceVariant = Black,
    outline = BorderLight,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color to enforce our custom black-and-white professional theme
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
