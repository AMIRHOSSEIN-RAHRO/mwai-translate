package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.api.GenerationConfig
import com.example.api.ImageConfig
import com.example.data.LinkedInDatabase
import com.example.data.LinkedInPost
import com.example.data.LinkedInRepository
import com.example.utils.LinkedInPrompts
import com.example.api.ApiKeyStorage
import com.example.api.ApiKeyConfig
import com.example.api.OpenAiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface GeneratorUiState {
    object Idle : GeneratorUiState
    object GeneratingPost : GeneratorUiState
    data class Success(val postText: String) : GeneratorUiState
    data class Error(val message: String) : GeneratorUiState
}

sealed interface VideoScriptUiState {
    object Idle : VideoScriptUiState
    object GeneratingScript : VideoScriptUiState
    data class Success(val scriptText: String) : VideoScriptUiState
    data class Error(val message: String) : VideoScriptUiState
}

sealed interface ImageUiState {
    object Idle : ImageUiState
    object Generating : ImageUiState
    data class Success(val bitmap: android.graphics.Bitmap) : ImageUiState
    data class Error(val message: String) : ImageUiState
}

class LinkedInViewModel(application: Application) : AndroidViewModel(application) {

    private val database = LinkedInDatabase.getDatabase(application)
    private val repository = LinkedInRepository(database.postDao())

    // History Flow
    val history: StateFlow<List<LinkedInPost>> = repository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _generatorState = MutableStateFlow<GeneratorUiState>(GeneratorUiState.Idle)
    val generatorState: StateFlow<GeneratorUiState> = _generatorState.asStateFlow()

    private val _videoScriptState = MutableStateFlow<VideoScriptUiState>(VideoScriptUiState.Idle)
    val videoScriptState: StateFlow<VideoScriptUiState> = _videoScriptState.asStateFlow()

    private val _imageState = MutableStateFlow<ImageUiState>(ImageUiState.Idle)
    val imageState: StateFlow<ImageUiState> = _imageState.asStateFlow()

    private val _appLanguage = MutableStateFlow("en")
    val appLanguage: StateFlow<String> = _appLanguage.asStateFlow()

    fun setLanguage(lang: String) {
        _appLanguage.value = lang
    }

    fun generatePost(topic: String, selectedHook: String?) {
        val currentLang = _appLanguage.value
        if (topic.isBlank()) {
            val errMsg = if (currentLang == "fa") "لطفاً موضوع، ایده یا متن خام را در کادر بالا وارد کنید." else "Please enter your topic, idea, or raw text in the box above."
            _generatorState.value = GeneratorUiState.Error(errMsg)
            return
        }

        _generatorState.value = GeneratorUiState.GeneratingPost
        _videoScriptState.value = VideoScriptUiState.Idle
        _imageState.value = ImageUiState.Idle

        viewModelScope.launch {
            val enabledKeys = ApiKeyStorage.getKeys(getApplication()).filter { it.isEnabled }
            val candidates = if (enabledKeys.isEmpty()) {
                listOf(ApiKeyConfig(id = "default_gemini", provider = "Gemini", modelName = "gemini-3.5-flash", apiKey = BuildConfig.GEMINI_API_KEY))
            } else {
                enabledKeys
            }

            val errorsList = mutableListOf<String>()
            var successText: String? = null

            for (keyCfg in candidates) {
                val keyToUse = keyCfg.apiKey
                if (keyToUse.isBlank() || keyToUse == "MY_GEMINI_API_KEY") {
                    val label = if (currentLang == "fa") "کلید خالی یا پیکربندی نشده" else "Empty API key"
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}): $label")
                    continue
                }

                try {
                    if (keyCfg.provider == "Gemini") {
                        val sysInstruction = Content(parts = listOf(Part(text = LinkedInPrompts.buildSystemInstruction(currentLang))))
                        val userPrompt = LinkedInPrompts.buildUserPrompt(topic, selectedHook, currentLang)
                        val userContent = Content(parts = listOf(Part(text = userPrompt)))

                        val request = GenerateContentRequest(
                            contents = listOf(userContent),
                            systemInstruction = sysInstruction
                        )

                        val response = withContext(Dispatchers.IO) {
                            RetrofitClient.service.generateContent(keyCfg.modelName, keyToUse, request)
                        }

                        val generatedText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        if (generatedText != null) {
                            successText = generatedText
                            break
                        } else {
                            val label = if (currentLang == "fa") "عدم پاسخ از سرور کاندید" else "Empty candidate content response"
                            errorsList.add("Gemini (${keyCfg.modelName}): $label")
                        }
                    } else if (keyCfg.provider == "OpenAI") {
                        val systemPrompt = LinkedInPrompts.buildSystemInstruction(currentLang)
                        val userPrompt = LinkedInPrompts.buildUserPrompt(topic, selectedHook, currentLang)

                        val request = com.example.api.OpenAiRequest(
                            model = keyCfg.modelName,
                            messages = listOf(
                                com.example.api.OpenAiMessage(role = "system", content = systemPrompt),
                                com.example.api.OpenAiMessage(role = "user", content = userPrompt)
                            )
                        )

                        val response = withContext(Dispatchers.IO) {
                            com.example.api.OpenAiClient.service.generateChatCompletion("Bearer $keyToUse", request)
                        }

                        val generatedText = response.choices?.firstOrNull()?.message?.content
                        if (generatedText != null) {
                            successText = generatedText
                            break
                        } else if (response.error?.message != null) {
                            errorsList.add("OpenAI (${keyCfg.modelName}): ${response.error.message}")
                        } else {
                            val label = if (currentLang == "fa") "پاسخ تهی کلوپاترا چت" else "Empty reply choices"
                            errorsList.add("OpenAI (${keyCfg.modelName}): $label")
                        }
                    }
                } catch (e: retrofit2.HttpException) {
                    val code = e.code()
                    val details = diagnoseHttpError(code, currentLang)
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}) [HTTP $code]: $details")
                } catch (e: Exception) {
                    val details = diagnoseException(e, currentLang)
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}): $details")
                }
            }

            if (successText != null) {
                _generatorState.value = GeneratorUiState.Success(successText)
                // Add to history
                val newItem = LinkedInPost(
                    topic = topic,
                    selectedHook = selectedHook,
                    generatedPost = successText
                )
                repository.insert(newItem)
            } else {
                val fullErrMsg = buildString {
                    if (currentLang == "fa") {
                        append("تمامی تلاش‌های هوش مصنوعی شکست خورد ❌\n")
                        errorsList.forEach { append("- $it\n") }
                        append("\n💡 راهکارهای پیشنهادی:\n")
                        append("۱. اینترنت، پروکسی یا قندشکن خود را بررسی، خاموش دائم یا عوض کنید.\n")
                        append("۲. وارد تنظیمات شده و مدل‌های بیشتری اضافه کنید یا کلیدهای خود را مجدداً تایید فرمائید.")
                    } else {
                        append("All API attempts failed ❌\n")
                        errorsList.forEach { append("- $it\n") }
                        append("\n💡 Suggestions:\n")
                        append("1. Verify network connection and proxy/VPN settings.\n")
                        append("2. Head to Settings to add alternative models or verify API Keys.")
                    }
                }
                _generatorState.value = GeneratorUiState.Error(fullErrMsg)
            }
        }
    }

    fun generateAiImage(topic: String) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            val errMsg = if (_appLanguage.value == "fa") "کلید API یافت نشد." else "API Key not found."
            _imageState.value = ImageUiState.Error(errMsg)
            return
        }

        _imageState.value = ImageUiState.Generating

        viewModelScope.launch {
            try {
                // Ensure visual prompt is in English for better image generation results
                val visualPrompt = "A modern professional digital graphic illustration for LinkedIn. Subject: $topic. Vibrant colors, clean minimalist corporate style, tech presentation, 8k resolution, highly creative masterwork."
                val userContent = Content(parts = listOf(Part(text = visualPrompt)))
                
                val request = GenerateContentRequest(
                    contents = listOf(userContent),
                    generationConfig = GenerationConfig(
                        responseModalities = listOf("IMAGE"),
                        imageConfig = ImageConfig(aspectRatio = "1:1", imageSize = "1K")
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent("gemini-2.5-flash-image", apiKey, request)
                }

                val inlineData = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.inlineData

                if (inlineData != null && !inlineData.data.isNullOrBlank()) {
                    val imageBytes = android.util.Base64.decode(inlineData.data, android.util.Base64.DEFAULT)
                    val bitmap = android.graphics.BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                    if (bitmap != null) {
                        _imageState.value = ImageUiState.Success(bitmap)
                    } else {
                        val errMsg = if (_appLanguage.value == "fa") "خطا در پردازش فایل تصویر." else "Failed to parse the generated image file."
                        _imageState.value = ImageUiState.Error(errMsg)
                    }
                } else {
                    val errMsg = if (_appLanguage.value == "fa") "اطلاعات تصویری از هوش مصنوعی دریافت نشد." else "No image data returned from AI."
                    _imageState.value = ImageUiState.Error(errMsg)
                }
            } catch (e: Exception) {
                val errMsg = if (_appLanguage.value == "fa") "خطا در تولید عکس: ${e.localizedMessage ?: "عدم اتصال به اینترنت"}" else "Image generation failed: ${e.localizedMessage ?: "Connection error"}"
                _imageState.value = ImageUiState.Error(errMsg)
            }
        }
    }

    fun generateVideoScript(postText: String) {
        val currentLang = _appLanguage.value
        _videoScriptState.value = VideoScriptUiState.GeneratingScript

        viewModelScope.launch {
            val enabledKeys = ApiKeyStorage.getKeys(getApplication()).filter { it.isEnabled }
            val candidates = if (enabledKeys.isEmpty()) {
                listOf(ApiKeyConfig(id = "default_gemini", provider = "Gemini", modelName = "gemini-3.5-flash", apiKey = BuildConfig.GEMINI_API_KEY))
            } else {
                enabledKeys
            }

            val errorsList = mutableListOf<String>()
            var successText: String? = null

            for (keyCfg in candidates) {
                val keyToUse = keyCfg.apiKey
                if (keyToUse.isBlank() || keyToUse == "MY_GEMINI_API_KEY") {
                    val label = if (currentLang == "fa") "کلید خالی یا پیکربندی نشده" else "Empty API key"
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}): $label")
                    continue
                }

                try {
                    val sysInstructionText = if (currentLang == "fa") {
                        "شما یک طراح سناریو ویدیو و استوری‌بورد حرفه‌ای لینکدین هستید. وظیفه شما تبدیل متن خام به سناریوهای ویدیویی جذاب، کوتاه و سریع است."
                    } else {
                        "You are an expert LinkedIn Video storyboard and reels script creator. Your task is to turn raw LinkedIn text content into high-converting, professional, fast-paced vertical video scripts."
                    }

                    val promptText = if (currentLang == "fa") {
                        """
                            این پست لینکدین را به یک سناریو و استوری‌بورد ویدیویی جذاب و ویروسی برای ریلز/شرتز تبدیل کنید. خروجی را به صورت زیر بخش‌بندی کنید:
                            ۱. **قلاب ویدیویی (Hook)** (۳ تا ۵ ثانیه اول - قلاب کلامی جذاب و سناریوی تصویر اولیه)
                            ۲. **بخش‌بندی صحنه‌ها (Scenes)** (جزئیات صحنه به صحنه، گوینده روی تصویر و متون افکت تصویری)
                            ۳. **دعوت به اقدام (CTA)** (دعوت نهایی به نظردهی یا اشتراک‌گذاری)
                            
                            سناریو را کاملاً جذاب و روان به زبان فارسی بنویسید.
                            
                            پست لینکدین:
                            $postText
                        """.trimIndent()
                    } else {
                        """
                            Turn this LinkedIn post into a highly engaging, viral Reels/Shorts video script. Structure the output into:
                            1. **Hook Segment** (First 3-5 seconds - high curiosity spoken hook and visual instructions)
                            2. **Scene breakdown** (Detailed scene-by-scene spoken voiceover and visual overlays)
                            3. **CTA** (Closing push for high engagement comments/shares)
                            
                            Write the video script guide naturally in English.
                            
                            LINKEDIN POST:
                            $postText
                        """.trimIndent()
                    }

                    if (keyCfg.provider == "Gemini") {
                        val sysInstruction = Content(parts = listOf(Part(text = sysInstructionText)))
                        val request = GenerateContentRequest(
                            contents = listOf(Content(parts = listOf(Part(text = promptText)))),
                            systemInstruction = sysInstruction
                        )

                        val response = withContext(Dispatchers.IO) {
                            RetrofitClient.service.generateContent(keyCfg.modelName, keyToUse, request)
                        }

                        val result = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        if (result != null) {
                            successText = result
                            break
                        } else {
                            val label = if (currentLang == "fa") "عدم پاسخ مناسب" else "No candidates found"
                            errorsList.add("Gemini (${keyCfg.modelName}): $label")
                        }
                    } else if (keyCfg.provider == "OpenAI") {
                        val request = com.example.api.OpenAiRequest(
                            model = keyCfg.modelName,
                            messages = listOf(
                                com.example.api.OpenAiMessage(role = "system", content = sysInstructionText),
                                com.example.api.OpenAiMessage(role = "user", content = promptText)
                            )
                        )

                        val response = withContext(Dispatchers.IO) {
                            com.example.api.OpenAiClient.service.generateChatCompletion("Bearer $keyToUse", request)
                        }

                        val result = response.choices?.firstOrNull()?.message?.content
                        if (result != null) {
                            successText = result
                            break
                        } else if (response.error?.message != null) {
                            errorsList.add("OpenAI (${keyCfg.modelName}): ${response.error.message}")
                        } else {
                            val label = if (currentLang == "fa") "پاسخ تهی چت‌جی‌پی‌تی" else "Empty reply choices"
                            errorsList.add("OpenAI (${keyCfg.modelName}): $label")
                        }
                    }
                } catch (e: retrofit2.HttpException) {
                    val code = e.code()
                    val details = diagnoseHttpError(code, currentLang)
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}) [HTTP $code]: $details")
                } catch (e: Exception) {
                    val details = diagnoseException(e, currentLang)
                    errorsList.add("${keyCfg.provider} (${keyCfg.modelName}): $details")
                }
            }

            if (successText != null) {
                _videoScriptState.value = VideoScriptUiState.Success(successText)
            } else {
                val fullErrMsg = buildString {
                    if (currentLang == "fa") {
                        append("تولید سناریوی ویدیو به دلیل خطای مدل‌ها شکست خورد ❌\n")
                        errorsList.forEach { append("- $it\n") }
                    } else {
                        append("Video script generation aborted due to model failures ❌\n")
                        errorsList.forEach { append("- $it\n") }
                    }
                }
                _videoScriptState.value = VideoScriptUiState.Error(fullErrMsg)
            }
        }
    }

    private fun diagnoseHttpError(code: Int, lang: String): String {
        return when (code) {
            401 -> if (lang == "fa") "کلید نامعتبر یا منقضی شده است (Unauthorized 401)." else "Invalid or expired API Key (Unauthorized 401)."
            403 -> if (lang == "fa") "دسترسی مسدود است؛ احتمالاً آی‌پی شما محدود است یا سهمیه حساب تمام شده (Forbidden 403)." else "Access forbidden; likely due to region restrictions or billing issues (Forbidden 403)."
            429 -> if (lang == "fa") "محدودیت تعداد درخواست پایان یافته؛ ترافیک سنگین یا سهمیه تمام شده (Rate Limit 429)." else "Rate Limit exceeded; temporary quota finished (Rate Limit 429)."
            500 -> if (lang == "fa") "خطای داخلی سرور ارائه‌دهینده سرویس (Server Error 500)." else "Internal host server error (Server Error 500)."
            503 -> if (lang == "fa") "سرور هوش مصنوعی به دلیل بار گرافیکی سنگین موقتاً خارج از دسترس است (Service Busy 503)." else "AI server temporarily busy and unavailable under heavy load (Service Busy 503)."
            else -> if (lang == "fa") "خطای HTTP شماره $code" else "HTTP error code $code"
        }
    }

    private fun diagnoseException(e: Exception, lang: String): String {
        val msg = e.localizedMessage ?: ""
        return if (msg.contains("Unable to resolve host") || msg.contains("ConnectException")) {
            if (lang == "fa") "عدم اتصال به اینترنت یا انسداد شبکه (پروکسی/VPN خود را بررسی کنید)" else "Internet disconnected or host blocked (Check VPN/proxy connection)"
        } else {
            msg
        }
    }

    fun deleteHistoryItem(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun resetStates() {
        _generatorState.value = GeneratorUiState.Idle
        _videoScriptState.value = VideoScriptUiState.Idle
        _imageState.value = ImageUiState.Idle
    }
}
