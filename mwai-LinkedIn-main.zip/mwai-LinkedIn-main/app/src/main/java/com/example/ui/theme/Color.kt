package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)
val NearBlack = Color(0xFF0A0A0A)
val SolidGray = Color(0xFF121212)
val DarkGray = Color(0xFF1E1E1E)
val MidGray = Color(0xFF888888)
val LightGray = Color(0xFFF2F2F2)
val BorderDark = Color(0xFF222222)
val BorderLight = Color(0xFFE2E2E2)
val AccentGray = Color(0xFF444444)

