package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextFieldDefaults
import com.example.data.LinkedInPost
import com.example.ui.GeneratorUiState
import com.example.ui.LinkedInViewModel
import com.example.ui.VideoScriptUiState
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.CardExporter
import com.example.utils.LinkedInPrompts
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import androidx.compose.ui.graphics.asImageBitmap
import com.example.ui.ImageUiState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.ui.graphics.graphicsLayer

class MainActivity : ComponentActivity() {
    private val viewModel: LinkedInViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    LinkedInMainScreen(
                        viewModel = viewModel,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

// --- Localized utility strings helper ---
private fun t(key: String, lang: String): String {
    return when (lang) {
        "fa" -> when (key) {
            "title" -> "قلم هوشمند MW"
            "subtitle" -> "دستیار حرفه‌ای محتوای لینکدین"
            "write_topic" -> "ایده یا موضوع پست خود را بنویسید"
            "placeholder" -> "مثال: ۳ روش طلایی برای بهبود لید از لینکدین یا معرفی پروژه جدید مبتنی بر پایتون..."
            "top_hooks" -> "۵۱ قالب هوک برتر لینکدین (اختیاری)"
            "clear_selection" -> "حذف انتخاب"
            "search_hook" -> "جستجوی قالب هوک..."
            "hook_active" -> "هوک انتخاب شده فعال:"
            "generate_btn" -> "ساخت پست حرفه‌ای لینکدین"
            "generating" -> "در حال نگارش خلاقانه..."
            "how_to_start" -> "موضوع خود را وارد کرده و دکمه بالا را بفشارید تا جادوی هوش مصنوعی SLAY آغاز شود."
            "analyzing" -> "هوش مصنوعی در حال تحلیل ایده و پیاده‌سازی متد لارا آکوستا (SLAY) است..."
            "generated_post" -> "پست تولید شده"
            "attachments_title" -> "ابزارهای ضمیمه جذب مشتری لینکدین:"
            "create_image_card" -> "طراحی کارت تصویر نقل‌قول"
            "create_video_script" -> "استودیو سناریو ویدیو"
            "reset" -> "شروع مجدد"
            "tab_create" -> "ساخت پست (Create)"
            "tab_history" -> "آرشیو تولیدات (History)"
            "clear_all_history" -> "حذف کل تاریخچه"
            "history_title" -> "تاریخچه تولیدات"
            "no_history" -> "هنوز هیچ پستی ثبت نشده است."
            "reload_hint" -> "بارگذاری مجدد برای ساخت عکس و ویدیو..."
            "settings" -> "تنظیمات برنامه"
            "language" -> "زبان برنامه"
            "english" -> "English (انگلیسی)"
            "persian" -> "فارسی (Persian)"
            "close" -> "بستن"
            else -> key
        }
        else -> when (key) {
            "title" -> "Smart Quill MW"
            "subtitle" -> "Professional LinkedIn Content Assistant"
            "write_topic" -> "Write your post topic or idea"
            "placeholder" -> "e.g., 3 golden ways to improve LinkedIn leads or introduce a new Python project..."
            "top_hooks" -> "Top 51 LinkedIn Hook Templates (Optional)"
            "clear_selection" -> "Clear Selection"
            "search_hook" -> "Search hook templates..."
            "hook_active" -> "Selected Hook Active:"
            "generate_btn" -> "Generate Professional LinkedIn Post"
            "generating" -> "Drafting creatively with AI..."
            "how_to_start" -> "Enter your topic and click the button above to start SLAY AI magic."
            "analyzing" -> "AI is analyzing your idea and implementing the SLAY copywriting framework..."
            "generated_post" -> "Generated Post"
            "attachments_title" -> "LinkedIn Client Attraction Tools:"
            "create_image_card" -> "Design Quote Card Image"
            "create_video_script" -> "Generate AI Video Script"
            "reset" -> "Reset Creator"
            "tab_create" -> "Create Workspace"
            "tab_history" -> "History Archive"
            "clear_all_history" -> "Clear All History"
            "history_title" -> "Generated History Logs"
            "no_history" -> "No generated posts found in history."
            "reload_hint" -> "Tap to load and generate AI visuals..."
            "settings" -> "App Settings"
            "language" -> "Language"
            "english" -> "English"
            "persian" -> "فارسی"
            "close" -> "Close"
            else -> key
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkedInMainScreen(
    viewModel: LinkedInViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    // States from viewmodel
    val history by viewModel.history.collectAsStateWithLifecycle()
    val generatorState by viewModel.generatorState.collectAsStateWithLifecycle()
    val videoScriptState by viewModel.videoScriptState.collectAsStateWithLifecycle()
    val imageUiState by viewModel.imageState.collectAsStateWithLifecycle()
    val lang by viewModel.appLanguage.collectAsStateWithLifecycle()

    // Screen states
    var rawText by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var selectedHookIndex by remember { mutableStateOf<Int?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Creator Panel, 1: History Archive

    // Image Card Designer States
    var showCardDialog by remember { mutableStateOf(false) }
    var cardName by remember { mutableStateOf("Amirhossein") }
    var cardHandle by remember { mutableStateOf("@linked_creator") }
    var cardQuoteSubset by remember { mutableStateOf("") }
    var cardBgStyle by remember { mutableStateOf(0) } // 0 to 4

    // Script / AI Studio Dialog States
    var showScriptDialog by remember { mutableStateOf(false) }
    var showAiImageDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Helpers to clear creator input
    fun resetCreator() {
        rawText = ""
        selectedHookIndex = null
        viewModel.resetStates()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- Slick Centered Header with Settings option ---
        SleekLogoHeader(
            lang = lang,
            onSettingsClick = { showSettingsDialog = true }
        )

        // --- Custom Segmented Slider/Tabs ---
        CustomSegmentedTabs(
            selectedTab = selectedTab,
            onTabSelected = { selectedTab = it },
            lang = lang,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        HorizontalDivider(
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            thickness = 1.dp,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (selectedTab) {
                0 -> { // Creator Workspace
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 24.dp, vertical = 16.dp)
                    ) {
                        // Topic Input Form
                        Text(
                            text = t("write_topic", lang),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        )

                        OutlinedTextField(
                            value = rawText,
                            onValueChange = { rawText = it },
                            placeholder = {
                                Text(
                                    text = t("placeholder", lang),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                                    textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(125.dp)
                                .testTag("raw_text_input"),
                            shape = RoundedCornerShape(12.dp),
                            textStyle = LocalTextStyle.current.copy(textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            ),
                            maxLines = 5,
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Default,
                                keyboardType = KeyboardType.Text
                            )
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Hook Selector Label & Filter query
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t("top_hooks", lang),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            if (selectedHookIndex != null) {
                                TextButton(
                                    onClick = { selectedHookIndex = null },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(t("clear_selection", lang), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        // Compact search bar for hooks
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    t("search_hook", lang),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            textStyle = TextStyle(fontSize = 13.sp),
                            singleLine = true,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            )
                        )

                        // Selector Box for HOOKS (Persian if "fa", English if "en")
                        val currentHooksList = LinkedInPrompts.getHooks(lang)
                        val filteredHooksWithIndices = currentHooksList.mapIndexed { idx, hook -> idx to hook }
                            .filter { it.second.contains(searchQuery, ignoreCase = true) }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            items(filteredHooksWithIndices) { (originalIndex, hookText) ->
                                val isSelected = selectedHookIndex == originalIndex
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .widthIn(max = 240.dp)
                                        .background(
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(
                                                alpha = 0.2f
                                            ),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            selectedHookIndex = originalIndex
                                        }
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = hookText,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        // Display selected hook alert
                        selectedHookIndex?.let { index ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp)
                                    .background(
                                        MaterialTheme.colorScheme.onBackground.copy(alpha = 0.03f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text(
                                        t("hook_active", lang),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = currentHooksList[index],
                                        style = MaterialTheme.typography.bodySmall,
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        // Submit action button (Solid Black in Light theme, Solid White in Dark theme)
                        Button(
                            onClick = {
                                val selectedHook = selectedHookIndex?.let { currentHooksList[it] }
                                viewModel.generatePost(rawText, selectedHook)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("generate_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (generatorState is GeneratorUiState.GeneratingPost) {
                                CircularProgressIndicator(
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = t("generating", lang),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Create,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = t("generate_btn", lang),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Output Block
                        Crossfade(
                            targetState = generatorState
                        ) { state ->
                            when (state) {
                                is GeneratorUiState.Idle -> {
                                    // Empty state helper
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 12.dp)
                                            .border(
                                                1.dp,
                                                MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(32.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = null,
                                                modifier = Modifier.size(44.dp),
                                                tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = t("how_to_start", lang),
                                                textAlign = TextAlign.Center,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                            )
                                        }
                                    }
                                }

                                is GeneratorUiState.GeneratingPost -> {
                                    CreativeProgressBanner(lang = lang, topic = rawText)
                                }

                                is GeneratorUiState.Success -> {
                                    LaunchedEffect(state.postText) {
                                        // Auto fill the card generator value with the first 4 lines of generated text
                                        cardQuoteSubset = state.postText.lines().take(4).joinToString("\n").trim()
                                    }

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(
                                                    alpha = 0.5f
                                                ),
                                                shape = RoundedCornerShape(14.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                                shape = RoundedCornerShape(14.dp)
                                            )
                                            .padding(16.dp)
                                    ) {
                                        // Header actions
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                // Copy Action
                                                IconButton(
                                                    onClick = {
                                                        clipboardManager.setText(AnnotatedString(state.postText))
                                                        Toast.makeText(context, if (lang == "fa") "متن پست کپی شد!" else "Post content copied!", Toast.LENGTH_SHORT).show()
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Copy"
                                                    )
                                                }
                                                // Share Action
                                                IconButton(
                                                    onClick = {
                                                        val sendIntent = Intent().apply {
                                                            action = Intent.ACTION_SEND
                                                            putExtra(Intent.EXTRA_TEXT, state.postText)
                                                            type = "text/plain"
                                                        }
                                                        context.startActivity(Intent.createChooser(sendIntent, "Share Post"))
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Share,
                                                        contentDescription = "Share"
                                                    )
                                                }
                                            }

                                            // Badge
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        MaterialTheme.colorScheme.primary,
                                                        RoundedCornerShape(6.dp)
                                                    )
                                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    text = t("generated_post", lang),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onPrimary
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        // Editable full output text
                                        SelectionContainer {
                                            Text(
                                                text = state.postText,
                                                style = MaterialTheme.typography.bodyMedium,
                                                lineHeight = 24.sp,
                                                textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(18.dp))

                                        Text(
                                            text = t("attachments_title", lang),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )

                                        // CUSTOM DOWNLOAD ATTACHMENT ACTIONS: IMAGE & VIDEO
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            // Quote Image Card Export Trigger (100% Reliable Offline Generation)
                                            Button(
                                                onClick = { showCardDialog = true },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.primary,
                                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Create,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(t("create_image_card", lang), style = MaterialTheme.typography.bodySmall)
                                            }

                                            // Video/Story Script Trigger
                                            Button(
                                                onClick = {
                                                    showScriptDialog = true
                                                    viewModel.generateVideoScript(state.postText)
                                                },
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    contentColor = MaterialTheme.colorScheme.surface
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(t("create_video_script", lang), style = MaterialTheme.typography.bodySmall)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))
                                        
                                        // Clean reset Button
                                        OutlinedButton(
                                            onClick = { resetCreator() },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(t("reset", lang), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }

                                is GeneratorUiState.Error -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .border(
                                                1.dp,
                                                MaterialTheme.colorScheme.error,
                                                RoundedCornerShape(10.dp)
                                            )
                                            .padding(14.dp)
                                    ) {
                                        Text(
                                            text = state.message,
                                            color = MaterialTheme.colorScheme.error,
                                            style = MaterialTheme.typography.bodySmall,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> { // History Archive List View
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp, vertical = 16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (history.isNotEmpty()) {
                                TextButton(
                                    onClick = { viewModel.clearAllHistory() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                                ) {
                                    Text(t("clear_all_history", lang), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Text(
                                text = "${t("history_title", lang)} (${history.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (history.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.List,
                                        contentDescription = null,
                                        modifier = Modifier.size(54.dp),
                                        tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.25f)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = t("no_history", lang),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                            ) {
                                items(history, key = { it.id }) { item ->
                                    HistoryPostRow(
                                        item = item,
                                        lang = lang,
                                        onLoad = {
                                            selectedTab = 0
                                            rawText = item.topic
                                            selectedHookIndex = null
                                            viewModel.generatePost(item.topic, item.selectedHook)
                                        },
                                        onDelete = { viewModel.deleteHistoryItem(item.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Tiny subtle credit sticker in the bottom corner ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "by amirhossein rahro",
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.35f),
                fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
            )
        }
    }

    // --- DIALOG FOR OFFLINE NATIVE LINKEDIN QUOTE CARD DESIGNER (Avoids 429 errors) ---
    if (showCardDialog) {
        AlertDialog(
            onDismissRequest = { showCardDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        CardExporter.generatePostCard(
                            context = context,
                            name = cardName,
                            handle = cardHandle,
                            quote = cardQuoteSubset.ifBlank { "Smart Quill MW provides exceptional assistance." },
                            bgStyle = cardBgStyle,
                            onSuccess = { uri ->
                                Toast.makeText(context, if (lang == "fa") "کارت تصویری لینکدین با موفقیت در گالری ذخیره شد!" else "LinkedIn Graphic Card saved to gallery!", Toast.LENGTH_SHORT).show()
                            },
                            onFailure = { ex ->
                                Toast.makeText(context, "Error: ${ex.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (lang == "fa") "صادر کردن به گالری" else "Export to Gallery")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCardDialog = false }) {
                    Text(t("close", lang))
                }
            },
            title = {
                Text(
                    text = if (lang == "fa") "طراحی و خروجی کارت پست" else "Quote Card Designer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (lang == "fa") "یک تصویر مربعی شکیل و حرفه‌ای از نقل‌قول این پست برای اشتراک‌گذاری در لینکدین بدون نیاز به نت بسازید." else "Create a stylish 1:1 rectangular card of your quote to increase organic views on LinkedIn.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // --- CARD LIVE PREVIEW IN JETPACK COMPOSE ---
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.95f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .background(
                                when (cardBgStyle) {
                                    0 -> Color(0xFF000000)
                                    1 -> Color(0xFF0F0F10)
                                    2 -> Color(0xFF14161C)
                                    3 -> Color(0xFFFFFFFF)
                                    else -> Color(0xFFF4F4F6)
                                }
                            )
                            .padding(24.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Header mockup
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "mwai LinkedIn post Generater",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Black else Color.White
                                )
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(
                                            color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Black else Color.White,
                                            shape = androidx.compose.foundation.shape.CircleShape
                                        )
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Sender Info Mockup
                            Column(horizontalAlignment = Alignment.Start) {
                                Text(
                                    text = cardName.ifBlank { "Name" },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Black else Color.White
                                )
                                Text(
                                    text = cardHandle.ifBlank { "@handle" },
                                    fontSize = 10.sp,
                                    color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Gray else Color.LightGray
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            HorizontalDivider(
                                color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.LightGray.copy(alpha = 0.5f) else Color.DarkGray.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Large quotation mark layout
                            Box(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "“",
                                    fontSize = 110.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (cardBgStyle == 3 || cardBgStyle == 4) Color(0xFFE2E2E6) else Color(0xFF1A1A1E),
                                    modifier = Modifier.offset(y = (-45).dp, x = (-4).dp)
                                )

                                Text(
                                    text = cardQuoteSubset.ifBlank { "Ready to share thoughts..." },
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    fontWeight = FontWeight.Normal,
                                    color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Black else Color.White,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Footer branded line
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (cardBgStyle == 3 || cardBgStyle == 4) Color(0xFFE5E5EA) else Color(0xFF1C1C1E),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "LINKEDIN CARD",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 7.sp,
                                        color = if (cardBgStyle == 3 || cardBgStyle == 4) Color.Black else Color.White
                                    )
                                }
                                Text(
                                    text = "JALB • ACCELERATE",
                                    fontSize = 7.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Styling controllers
                    Text(
                        text = if (lang == "fa") "انتخاب تم رنگی پس‌زمینه:" else "Select background style theme:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val colorsList = listOf(
                            Color.Black to "Black",
                            Color(0xFF0F0F10) to "Slate",
                            Color(0xFF1C1D24) to "Slate-G",
                            Color.White to "White",
                            Color(0xFFF4F4F6) to "Gray"
                        )
                        colorsList.forEachIndexed { index, pair ->
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(pair.first, RoundedCornerShape(6.dp))
                                    .border(
                                        width = if (cardBgStyle == index) 2.dp else 1.dp,
                                        color = if (cardBgStyle == index) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { cardBgStyle = index }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = cardName,
                        onValueChange = { cardName = it },
                        label = { Text(if (lang == "fa") "نام شما" else "Your Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = cardHandle,
                        onValueChange = { cardHandle = it },
                        label = { Text(if (lang == "fa") "نام کاربری لینکدین" else "LinkedIn Handle") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = cardQuoteSubset,
                        onValueChange = { cardQuoteSubset = it },
                        label = { Text(if (lang == "fa") "متن نقل‌قول کارت" else "Quote Message") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        maxLines = 4,
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            },
            shape = RoundedCornerShape(16.dp),
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier.padding(24.dp)
        )
    }

    // --- BILINGUAL SETTINGS MODAL DIALOG (Satisfies requirement 3) ---
    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            confirmButton = {
                Button(
                    onClick = { showSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(t("close", lang))
                }
            },
            title = {
                Text(
                    text = t("settings", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = t("language", lang),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // English option
                        Button(
                            onClick = { viewModel.setLanguage("en") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lang == "en") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (lang == "en") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(t("english", lang), style = MaterialTheme.typography.bodySmall)
                        }

                        // Persian option
                        Button(
                            onClick = { viewModel.setLanguage("fa") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lang == "fa") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (lang == "fa") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(t("persian", lang), style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    ApiKeyManagerSection(lang = lang, context = LocalContext.current)
                }
            },
            shape = RoundedCornerShape(16.dp),
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier.padding(24.dp)
        )
    }

    // --- STORY SCRIPT & STORYBOARD VIDEO DIALOG (Satisfies requirement 2) ---
    if (showScriptDialog) {
        AlertDialog(
            onDismissRequest = { showScriptDialog = false },
            confirmButton = {
                Button(
                    onClick = { showScriptDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(t("close", lang))
                }
            },
            title = {
                Text(
                    text = if (lang == "fa") "سناریو و استوری‌بورد تصویری ویدیو" else "Video Script & Visual Storyboard",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                ) {
                    when (val state = videoScriptState) {
                        is VideoScriptUiState.Idle -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        }

                        is VideoScriptUiState.GeneratingScript -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(strokeWidth = 3.dp)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = if (lang == "fa") "در حال پیاده‌سازی متنی سناریو..." else "Drafting horizontal screenplay...",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        is VideoScriptUiState.Success -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(state.scriptText))
                                            Toast.makeText(context, if (lang == "fa") "سناریو ویدیو کپی شد!" else "Video script copied!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(imageVector = Icons.Default.Check, contentDescription = "Copy script")
                                    }
                                    Text(if (lang == "fa") "کپی سناریو متنی" else "Copy Text Script", style = MaterialTheme.typography.labelSmall)
                                }
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                SelectionContainer {
                                    Text(
                                        text = state.scriptText,
                                        style = MaterialTheme.typography.bodySmall,
                                        lineHeight = 22.sp,
                                        textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }

                                Spacer(modifier = Modifier.height(24.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(18.dp))

                                // AI Storyboard Image Frame
                                Text(
                                    text = if (lang == "fa") "تصویر کلیدی سناریو با هوش مصنوعی" else "AI Storyboard Key-Frame",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (lang == "fa") "با مدل تصویرساز، سبک بصری فریم کلیدی این ویدیو را تولید کنید." else "Use the AI generator to style-frame the visual theme for this video proposal.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(14.dp))

                                when (val imgState = imageUiState) {
                                    is ImageUiState.Idle -> {
                                        Button(
                                            onClick = { viewModel.generateAiImage("Vertical smartphone vertical reels shoot: " + rawText) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(if (lang == "fa") "تولید فریم کلیدی سناریو" else "Generate Video Frame Image")
                                        }
                                    }
                                    is ImageUiState.Generating -> {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            CircularProgressIndicator()
                                            Text(
                                                text = if (lang == "fa") "در حال طراحی بصری فریم ویدیو..." else "Style framing video scenes...",
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                    is ImageUiState.Success -> {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Image(
                                                bitmap = imgState.bitmap.asImageBitmap(),
                                                contentDescription = "AI Video Frame",
                                                modifier = Modifier
                                                    .fillMaxWidth(0.9f)
                                                    .aspectRatio(0.6f) // vertical reels format
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            TextButton(
                                                onClick = {
                                                    CardExporter.saveRawImageToGallery(
                                                        context = context,
                                                        bitmap = imgState.bitmap,
                                                        filename = "ai_video_storyframe_${System.currentTimeMillis()}.png",
                                                        onSuccess = {
                                                            Toast.makeText(context, if (lang == "fa") "فریم استوری‌بورد در گالری ذخیره شد!" else "Storyboard frame saved to gallery!", Toast.LENGTH_SHORT).show()
                                                        },
                                                        onFailure = { ex ->
                                                            Toast.makeText(context, "Failed: ${ex.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    )
                                                }
                                            ) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(if (lang == "fa") "ذخیره فریم تصویری در گالری" else "Save Scene Image to Gallery")
                                            }
                                        }
                                    }
                                    is ImageUiState.Error -> {
                                        Text(imgState.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Button(
                                            onClick = { viewModel.generateAiImage("Vertical reels screen capture: " + rawText) },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(if (lang == "fa") "تلاش مجدد بصری" else "Try Visuals Again")
                                        }
                                    }
                                }
                            }
                        }

                        is VideoScriptUiState.Error -> {
                            Text(
                                text = "Error: ${state.message}",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier.padding(24.dp)
        )
    }
}

@Composable
fun SleekLogoHeader(
    lang: String,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 24.dp, top = 20.dp, end = 24.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary,
                        shape = RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
//                     imageVector = Icons.Default.Create,
                    imageVector = Icons.Default.Create,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(10.dp))
            
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = t("title", lang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = t("subtitle", lang),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
            }
        }

        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier
                .size(36.dp)
                .background(
                    MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(8.dp)
                )
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun CustomSegmentedTabs(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    lang: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        val options = listOf(t("tab_create", lang), t("tab_history", lang))
        options.forEachIndexed { index, text ->
            val isSelected = selectedTab == index
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.background else Color.Transparent
                    )
                    .clickable { onTabSelected(index) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onBackground.copy(
                        alpha = 0.6f
                    )
                )
            }
        }
    }
}

@Composable
fun HistoryPostRow(
    item: LinkedInPost,
    lang: String,
    onLoad: () -> Unit,
    onDelete: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
    val formattedDate = formatter.format(Date(item.timestamp))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                RoundedCornerShape(10.dp)
            )
            .clickable { onLoad() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(18.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete post",
                    tint = Color.Red.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }

            Column(horizontalAlignment = if (lang == "fa") Alignment.End else Alignment.Start) {
                Text(
                    text = item.topic,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Snippet preview of the output
        Text(
            text = item.generatedPost,
            style = MaterialTheme.typography.bodySmall,
            lineHeight = 18.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = t("reload_hint", lang),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// --- CREATIVE PROGRESS STEPS COMPOSABLE ---
@Composable
fun CreativeProgressBanner(lang: String, topic: String) {
    val keywords = remember(topic) {
        if (topic.isBlank()) {
            if (lang == "fa") "ایده ارزشمند شما" else "your shiny idea"
        } else {
            val words = topic.trim().split("\\s+".toRegex()).filter { it.length > 2 }
            if (words.isEmpty()) {
                if (topic.length > 15) topic.take(15) + "..." else topic
            } else {
                words.take(2).joinToString(" ")
            }
        }
    }

    val steps = if (lang == "fa") {
        listOf(
            "تحلیل اولیه ایده درباره «$keywords»",
            "طراحی هوک فوق‌جاذب برای مهار مخاطب در لینکدین",
            "تنظیم درس‌های کلیدی و سناریوی کاربردی",
            "روان‌سازی ریتم خوانش بر اساس فرمول SLAY",
            "صیقل نهایی و زیباسازی پاراگراف‌ها با پارامترهای تعاملی"
        )
    } else {
        listOf(
            "Analyzing core concepts of \"$keywords\"",
            "Synthesizing attention-grabbing hooks for LinkedIn",
            "Drafting actionable guidelines & standard lessons",
            "Structuring text flow using SLAY framework rules",
            "Final copyediting and aesthetic visual spacing"
        )
    }

    val thoughts = if (lang == "fa") {
        listOf(
            "🔍 در حال مدل‌سازی کلمات کلیدی روی تم: «$keywords»...",
            "🧠 کاوش در بایگانی الگوهای ویروسی لینکدین برای بخش «$keywords»...",
            "📝 تعبیه‌سازی قلاب کنجکاوی در سطرهای آغازین...",
            "⚙️ محاسبه توزیع خوانایی پاراگراف‌ها و چگالی متن...",
            "🔬 همسان‌سازی لحن برای بهینه‌سازی تأثیر کلام...",
            "💎 جایگذاری هوشمند اموجی‌های مرتبط برای متمایز کردن پست در هوم...",
            "🚀 روان‌سازی مکث‌های بصری جهت پیشگیری از فرار سریع تماشاگر...",
            "🪄 کپی‌رایتینگ به اتمام رسید؛ در حال بازبینی دستوری لایه‌های متن و ساختار..."
        )
    } else {
        listOf(
            "🔍 Deconstructing semantic concepts around \"$keywords\"...",
            "🧠 Scanning top LinkedIn templates related to \"$keywords\"...",
            "📝 Drafting deep psychological hooks...",
            "⚙️ Map testing cognitive density & paragraph heights...",
            "🔬 Executing voice frequency filters for executive style...",
            "💎 Calculating emoji placements for high visual engagement...",
            "🚀 Inserting visual spacers to prevent instant scrolling...",
            "🪄 Scripting complete! Wrapping up final structural revisions..."
        )
    }

    var currentStepIdx by remember { mutableStateOf(0) }
    var progressVal by remember { mutableStateOf(0.1f) }
    var consoleLogs by remember { mutableStateOf(listOf<String>()) }

    LaunchedEffect(Unit) {
        while (currentStepIdx < steps.size - 1) {
            kotlinx.coroutines.delay(1800)
            currentStepIdx++
            progressVal = (currentStepIdx + 1) / steps.size.toFloat()
        }
    }

    LaunchedEffect(Unit) {
        for (i in thoughts.indices) {
            consoleLogs = consoleLogs + thoughts[i]
            kotlinx.coroutines.delay(1200)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Elegant pulsing scale transition
            val infiniteTransition = rememberInfiniteTransition(label = "pulse_trans")
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.9f,
                targetValue = 1.1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale_pulse"
            )

            Box(
                modifier = Modifier
                    .size(60.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Create,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(30.dp)
                        .graphicsLayer(scaleX = scale, scaleY = scale)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (lang == "fa") "دستیار خلاق کپی‌رایتینگ در حال تفکر است..." else "Creative Copywriter Assistant Thinking...",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progressVal },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Checklists
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                steps.forEachIndexed { index, stepText ->
                    val isCompleted = index < currentStepIdx
                    val isActive = index == currentStepIdx

                    val alpha = if (isCompleted || isActive) 1.0f else 0.4f
                    val textColor = if (isActive) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurface.copy(alpha = alpha)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = if (lang == "fa") Arrangement.End else Arrangement.Start
                    ) {
                        if (lang != "fa") {
                            StepIcon(isCompleted = isCompleted, isActive = isActive)
                            Spacer(modifier = Modifier.width(10.dp))
                        }

                        Text(
                            text = stepText,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                            color = textColor,
                            textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                            modifier = Modifier.weight(1f)
                        )

                        if (lang == "fa") {
                            Spacer(modifier = Modifier.width(10.dp))
                            StepIcon(isCompleted = isCompleted, isActive = isActive)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // LIVE AI THINKING CONSOLE TERMINAL (Provides rich waiting interactivity)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0C1017) // Dark slate terminal background
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFF1F2937))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.size(6.dp).background(Color(0xFFFF5F56), androidx.compose.foundation.shape.CircleShape))
                            Box(modifier = Modifier.size(6.dp).background(Color(0xFFFFBD2E), androidx.compose.foundation.shape.CircleShape))
                            Box(modifier = Modifier.size(6.dp).background(Color(0xFF27C93F), androidx.compose.foundation.shape.CircleShape))
                        }
                        Text(
                            text = if (lang == "fa") "تفکر فعال هوش مصنوعی" else "AI Thought Console",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF9CA3AF),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val activeLogs = consoleLogs.takeLast(3)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activeLogs.forEachIndexed { i, log ->
                            val isLast = i == activeLogs.lastIndex
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (lang == "fa") Arrangement.End else Arrangement.Start
                            ) {
                                Text(
                                    text = log + (if (isLast) " ▊" else ""),
                                    style = androidx.compose.ui.text.TextStyle(
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                        color = if (isLast) Color(0xFF10B981) else Color(0xFF34D399)
                                    ),
                                    fontSize = 11.sp,
                                    textAlign = if (lang == "fa") TextAlign.Right else TextAlign.Left,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StepIcon(isCompleted: Boolean, isActive: Boolean) {
    if (isCompleted) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF4CAF50),
            modifier = Modifier.size(16.dp)
        )
    } else if (isActive) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.primary
        )
    } else {
        Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
            modifier = Modifier.size(14.dp)
        )
    }
}

// --- MULTI-PROVIDER API KEY MANAGER (Satisfies Requirement) ---
@Composable
fun ApiKeyManagerSection(lang: String, context: android.content.Context) {
    var keysList by remember { mutableStateOf(com.example.api.ApiKeyStorage.getKeys(context)) }

    var selectedProvider by remember { mutableStateOf("Gemini") }
    var selectedModelPreset by remember { mutableStateOf("") }
    var customModelName by remember { mutableStateOf("") }
    var enteredApiKey by remember { mutableStateOf("") }

    val modelPresets = if (selectedProvider == "Gemini") {
        listOf("gemini-1.5-flash", "gemini-2.5-flash", "gemini-1.5-pro")
    } else {
        listOf("gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo")
    }

    LaunchedEffect(selectedProvider) {
        selectedModelPreset = modelPresets.first()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(
            text = if (lang == "fa") "🔑 مدیریت مستقل کلیدهای API" else "🔑 Multi-Provider API Keys",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = if (lang == "fa") {
                "امکان ثبت زنجیره‌ای از کلیدهای شخصی. در صورت بروز خطا یا محدودیت مصرف (مثلاً ارور ۴۲۹ یا ۵۰۳) برنامه سریعاً روی مدل پشتیبان بعدی سوئیچ خواهد کرد."
            } else {
                "Automated failover list. If any key reaches rate limit or throws an HTTP 429/503 error, the generator automatically switches to the next fallback key."
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // LIST OF KEY CARDS
        if (keysList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (lang == "fa") "کلید فعالی ثبت نشده (استفاده از مدل پیش‌فرض)" else "No custom keys. Using internal defaults.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                keysList.forEach { key ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (key.provider == "Gemini") Color(0xFF1E88E5) else Color(0xFF10B981),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = key.provider,
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = key.modelName,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "•••• " + key.apiKey.takeLast(4),
                                style = androidx.compose.ui.text.TextStyle(
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                ),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                            )
                        }

                        // Toggle key
                        Switch(
                            checked = key.isEnabled,
                            onCheckedChange = { enabled ->
                                com.example.api.ApiKeyStorage.toggleKey(context, key.id, enabled)
                                keysList = com.example.api.ApiKeyStorage.getKeys(context)
                            },
                            modifier = Modifier.graphicsLayer(scaleX = 0.8f, scaleY = 0.8f)
                        )

                        // Delete button
                        IconButton(
                            onClick = {
                                com.example.api.ApiKeyStorage.deleteKey(context, key.id)
                                keysList = com.example.api.ApiKeyStorage.getKeys(context)
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
        Spacer(modifier = Modifier.height(12.dp))

        // ADD NEW FORM
        Text(
            text = if (lang == "fa") "➕ ثبت کلید و مدل هوش مصنوعی" else "➕ Add Custom Provider Key",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Provider Selector Switch (Gemini vs OpenAI)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { selectedProvider = "Gemini" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedProvider == "Gemini") MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent,
                    contentColor = if (selectedProvider == "Gemini") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                ),
                border = BorderStroke(1.dp, if (selectedProvider == "Gemini") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("Google Gemini", style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = { selectedProvider = "OpenAI" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedProvider == "OpenAI") MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f) else Color.Transparent,
                    contentColor = if (selectedProvider == "OpenAI") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                ),
                border = BorderStroke(1.dp, if (selectedProvider == "OpenAI") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text("OpenAI ChatGPT", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = if (lang == "fa") "انتخاب نسخه مدل معروف:" else "Select Famous Model Version:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            modelPresets.forEach { model ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (selectedModelPreset == model) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { selectedModelPreset = model }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = model.replace("gemini-", "").replace("gpt-", ""),
                        color = if (selectedModelPreset == model) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = customModelName,
            onValueChange = { customModelName = it },
            label = {
                Text(
                    text = if (lang == "fa") "یا نام مدل دستی (مثلاً gpt-4o)" else "Or Custom Model Identifier",
                    style = MaterialTheme.typography.labelSmall
                )
            },
            placeholder = { Text(selectedModelPreset, style = MaterialTheme.typography.bodySmall) },
            singleLine = true,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodySmall
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = enteredApiKey,
            onValueChange = { enteredApiKey = it },
            label = {
                Text(
                    text = if (lang == "fa") "رمز / کلید API (مثلاً sk-...)" else "API Key Secret (sk-...)",
                    style = MaterialTheme.typography.labelSmall
                )
            },
            singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
            textStyle = MaterialTheme.typography.bodySmall
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = {
                if (enteredApiKey.isNotBlank()) {
                    val finalModel = if (customModelName.isNotBlank()) customModelName.trim() else selectedModelPreset
                    val newKey = com.example.api.ApiKeyConfig(
                        id = java.util.UUID.randomUUID().toString(),
                        provider = selectedProvider,
                        modelName = finalModel,
                        apiKey = enteredApiKey.trim()
                    )
                    com.example.api.ApiKeyStorage.addKey(context, newKey)
                    keysList = com.example.api.ApiKeyStorage.getKeys(context)
                    enteredApiKey = ""
                    customModelName = ""
                }
            },
            enabled = enteredApiKey.isNotBlank(),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                text = if (lang == "fa") "✔ ثبت کلید در زنجیره‌ مدل‌ها" else "✔ Register in Model Chain",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

